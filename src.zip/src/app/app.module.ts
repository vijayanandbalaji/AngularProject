import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { RouterModule } from '@angular/router';


import { UserSignupComponent } from './user-details/user-signup/user-signup.component';
import { MentorSignupComponent } from './mentor-details/mentor-signup/mentor-signup.component';
import { UserMenuComponent } from './user-details/user-menu/user-menu.component';
import { TrainerMenuComponent } from './mentor-details/trainer-menu/trainer-menu.component';
import { AdminLoginComponent } from './admin-details/admin-login/admin-login.component';
import { AdminHomeComponent } from './admin-details/admin-home/admin-home.component';
import { MentorLoginComponent } from './mentor-details/mentor-login/mentor-login.component';
import { UserLoginComponent } from './user-details/user-login/user-login.component';
import { SearchTrainingComponent } from './user-details/search-training/search-training.component';




@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    UserLoginComponent,
    MentorLoginComponent,
    UserSignupComponent,
    MentorSignupComponent,
    UserMenuComponent,
    TrainerMenuComponent,
    AdminLoginComponent,
    AdminHomeComponent,
    SearchTrainingComponent,
    

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      { path: '', component: HeaderComponent , pathMatch:'full' },
      {path:'userlogin',component:UserLoginComponent},
      {path:'mentorlogin',component:MentorLoginComponent},
      {path:'usersignup',component:UserSignupComponent},
      {path:'mentorsignup',component:MentorSignupComponent},
      {path:'userhome',component:UserMenuComponent},
      {path:'mentorhome',component:TrainerMenuComponent},
      {path:'adminlogin',component:AdminLoginComponent},
      {path:'adminhome',component:AdminHomeComponent},
      {path:'searchtraining',component:SearchTrainingComponent}
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
