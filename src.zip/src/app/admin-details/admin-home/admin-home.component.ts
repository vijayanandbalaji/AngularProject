import { Component, OnInit } from '@angular/core';
import { Skill } from '../skill/skill.model';
import { SkillService } from '../skill/skill.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-home',
  templateUrl: './admin-home.component.html',
  styleUrls: ['./admin-home.component.css']
})
export class AdminHomeComponent implements OnInit {

  skill : Skill = new Skill();

  constructor(private skillService: SkillService,private router:Router) { }

  ngOnInit() {
  }

  add()
  {
    this.skillService.addSkill(this.skill)
      .subscribe(data => {
        console.log(data)
        this.router.navigate(["/adminhome"])
      }
        , error => console.log(error));
    this.skill = new Skill();
  }

  addskills() {
    this.add();
  }
}
