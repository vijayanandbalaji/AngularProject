export class Admin
{
    id:number;
    name:String;
    email:String;
    password:String;
    contact:number;
}