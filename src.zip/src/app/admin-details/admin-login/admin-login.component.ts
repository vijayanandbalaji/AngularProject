import { Component, OnInit } from '@angular/core';
import { Admin } from '../admin/admin.model';
import { AdminService } from '../admin/admin.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {

  admin: Admin = new Admin();

  constructor(private adminService: AdminService, private router: Router) { }

  ngOnInit() {
  }


  checkLogin() {
    this.adminService.loginAdmin(this.admin.email, this.admin.password)
      .subscribe((data: Admin) => {
        console.log(data)
        if (data != null) {
          this.router.navigate(["/adminhome"])
        }
      }
        , error => console.log(error));
    this.admin = new Admin();

  }


  adminLogin() {
    this.checkLogin();
  }
}
