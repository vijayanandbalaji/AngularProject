import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Skill } from './skill.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SkillService {
  private baseUrl = 'http://localhost:9531/skills';
  constructor(private http: HttpClient) { }

  addSkill(skill : Skill ): Observable<Object> {
    return this.http.post(`${this.baseUrl}/skills/add`, skill);
  }

  displaySkills() : Observable<Skill[]>{
     return this.http.get<Skill[]>(`${this.baseUrl}/display/skills`);
   }
}
