import { Component, OnInit } from '@angular/core';
import { MentorSkill } from 'src/app/mentor-details/mentor-skill/mentorskill.model';
import { Router } from '@angular/router';
import { MentorskillService } from 'src/app/mentor-details/mentor-skill/mentorskill.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-search-training',
  templateUrl: './search-training.component.html',
  styleUrls: ['./search-training.component.css']
})
export class SearchTrainingComponent implements OnInit {

  mentors:Observable<MentorSkill[]>
 // mentorskill : MentorSkill=new MentorSkill();


  constructor(private mentorskillService:MentorskillService,private router:Router) { }

  ngOnInit() {
    this.mentors=this.mentorskillService.displayMentors()
  }


propose()
{

}

  //propose button 
  proposeT()
  {
    this.propose()
  }
}
