import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Mentor } from './mentor.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MentorService {

  private baseUrl = 'http://localhost:9531/mentor';

  constructor(private http: HttpClient) { }

  createMentor(mentor: Mentor): Observable<Object> {
    return this.http.post(`${this.baseUrl}/mentor/create`, mentor);
  }

  loginMentor(emailId: String, password: String): Observable<Object> {
    return this.http.get(`${this.baseUrl}/mentor/login/${emailId}/${password}`);
  }
}
