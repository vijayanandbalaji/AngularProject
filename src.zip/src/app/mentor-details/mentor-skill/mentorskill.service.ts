import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { MentorSkill } from './mentorskill.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MentorskillService {
  private baseUrl = 'http://localhost:9531/mentorskill';

  constructor(private http: HttpClient) { }

  MentorSkillAdd(mentorskill: MentorSkill): Observable<any> {
    return this.http.post(`${this.baseUrl}/mentorskill/add`, mentorskill);
  }


  displayMentors() : Observable<MentorSkill[]>{
    return this.http.get<MentorSkill[]>(`${this.baseUrl}/display/mentors`);
  }
}
