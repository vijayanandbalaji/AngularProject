import { Mentor } from '../mentor/mentor.model';
import { Skill } from 'src/app/admin-details/skill/skill.model';

export class Calendar
{
    id : number;
    mentorDetails:Mentor;
    skillDetails:Skill;
    timing:String;
    startDate:Date;
    endDate:Date;

}