import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Calendar } from './calendar';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CalendarService {
  private baseUrl = 'http://localhost:9531/calendar';
  constructor(private http: HttpClient) { }

  calendarAdd(calendar : Calendar): Observable<any> {
    return this.http.post(`${this.baseUrl}/calendar/add`, calendar);
  }
}
