import { Component, OnInit } from '@angular/core';
import { Skill } from 'src/app/admin-details/skill/skill.model';
import { Router } from '@angular/router';
import { SkillService } from 'src/app/admin-details/skill/skill.service';
import { UserService } from 'src/app/user-details/user/user.service';
import { Observable } from 'rxjs';
import { MentorSkill } from '../mentor-skill/mentorskill.model';
import { MentorskillService } from '../mentor-skill/mentorskill.service';
import { Mentor } from '../mentor/mentor.model';
import { MentorService } from '../mentor/mentor.service';
import { Calendar } from '../mentor-calendar/calendar';
import { CalendarService } from '../mentor-calendar/calendar.service';

@Component({
  selector: 'app-trainer-menu',
  templateUrl: './trainer-menu.component.html',
  styleUrls: ['./trainer-menu.component.css']
})
export class TrainerMenuComponent implements OnInit {
  skill : Skill = new Skill();
  mentorskill:MentorSkill =new MentorSkill();
  mentor:Mentor=new Mentor();
  calendar:Calendar=new Calendar();
  onadd : Skill=new Skill();

  calskill : Skill ;
  skills:Observable<Skill[]> 
  
  constructor(private skillService: SkillService,private mentoskillService:MentorskillService,private calendarService:CalendarService,private router:Router) { }
  
  //used to display the skill table content
  ngOnInit() {
    this.skills=this.skillService.displaySkills()
  
  }


//passing the component data to service
  skillofmentor()
  {

      this.mentorskill.mentorDetails=JSON.parse(localStorage.getItem('data'));
       this.mentorskill.skillDetails=this.onadd;
       this.mentoskillService.MentorSkillAdd(this.mentorskill)
        .subscribe((data: MentorSkill) => {
           console.log(data)
           if (data != null) {
             this.router.navigate(["/mentorhome"])
            }
          }

      , error => console.log(error));
  this.mentorskill = new MentorSkill(); 
  }


  calen()
  {
    this.calendar.mentorDetails=JSON.parse(localStorage.getItem('data'));
    this.calendar.skillDetails=this.calskill;
    this.calendarService.calendarAdd(this.calendar)
    .subscribe((data:Calendar) =>{
      console.log(data)
      if(data != null){
        this.router.navigate(["/mentorhome"])
      }
    }
    , error => console.log(error));
  this.calendar = new Calendar(); 

  }


  
  // form button action
  mentorskills()
  {
    this.skillofmentor();
  }


  // this is display selected skill name
  addon(skill:Skill)
  {
    this.onadd=skill;
   
  }

  //cal update for specific technology
  cal(skill:Skill)
  {
    this.calskill=skill;
  }

  mentorcal()
  {
    this.calen();
  }
}
