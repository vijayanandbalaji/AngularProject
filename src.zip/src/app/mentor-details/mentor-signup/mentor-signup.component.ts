import { Component, OnInit } from '@angular/core';
import { Mentor } from '../mentor/mentor.model';
import { MentorService } from '../mentor/mentor.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-mentor-signup',
  templateUrl: './mentor-signup.component.html',
  styleUrls: ['./mentor-signup.component.css']
})
export class MentorSignupComponent implements OnInit {

  mentor: Mentor = new Mentor();

  constructor(private mentorService:MentorService,private router:Router) { }

  ngOnInit() {
  }

  save() {
    this.mentorService.createMentor(this.mentor)
      .subscribe(data => {
        console.log(data)
        this.router.navigate(["/mentorlogin"])
      }
        , error => console.log(error));
    this.mentor = new Mentor();
  }


  onSubmit() {
    this.save();
  }
}