export class User{
    id:number;
    userName:String;
    emailId:String;
    password:String;
    userRegDateTime:Date;
    userRegCode:String;
    active:number;
}