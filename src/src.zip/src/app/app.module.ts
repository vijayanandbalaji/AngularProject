import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { RouterModule } from '@angular/router';
import { UserLoginComponent } from './user-login/user-login.component';

import { UserSignupComponent } from './user-signup/user-signup.component';
import { MentorSignupComponent } from './mentor-signup/mentor-signup.component';
import { UserMenuComponent } from './user-menu/user-menu.component';
import { TrainerMenuComponent } from './trainer-menu/trainer-menu.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { MentorLoginComponent } from './mentor-login/mentor-login.component';



@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    UserLoginComponent,
    MentorLoginComponent,
    UserSignupComponent,
    MentorSignupComponent,
    UserMenuComponent,
    TrainerMenuComponent,
    AdminLoginComponent,
    AdminHomeComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      { path: '', component: HeaderComponent , pathMatch:'full' },
      {path:'userlogin',component:UserLoginComponent},
      {path:'mentorlogin',component:MentorLoginComponent},
      {path:'usersignup',component:UserSignupComponent},
      {path:'mentorsignup',component:MentorSignupComponent},
      {path:'userhome',component:UserMenuComponent},
      {path:'mentorhome',component:TrainerMenuComponent},
      {path:'adminlogin',component:AdminLoginComponent},
      {path:'adminhome',component:AdminHomeComponent}
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
