import { Component, OnInit } from '@angular/core';
import { Skill } from 'src/app/admin-details/skill/skill.model';
import { Router } from '@angular/router';
import { SkillService } from 'src/app/admin-details/skill/skill.service';
import { UserService } from 'src/app/user-details/user/user.service';
import { Observable } from 'rxjs';
import { MentorSkill } from '../mentor-skill/mentorskill.model';
import { MentorskillService } from '../mentor-skill/mentorskill.service';

@Component({
  selector: 'app-trainer-menu',
  templateUrl: './trainer-menu.component.html',
  styleUrls: ['./trainer-menu.component.css']
})
export class TrainerMenuComponent implements OnInit {
  skill : Skill = new Skill();
  mentorskill:MentorSkill =new MentorSkill();

  onadd : Skill=new Skill();

  skills:Observable<Skill[]> 
  constructor(private skillService: SkillService,private mentoskillService:MentorskillService,private router:Router) { }
  
  ngOnInit() {
    this.skills=this.skillService.displaySkills()
  }



  skillofmentor()
  {

  }

  mentorskills()
  {
    this.skillofmentor();
  }

  addon(skill:Skill)
  {
    this.onadd=skill;
  }

}
