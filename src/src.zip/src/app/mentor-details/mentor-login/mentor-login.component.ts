import { Component, OnInit } from '@angular/core';
import { Mentor } from '../mentor/mentor.model';
import { MentorService } from '../mentor/mentor.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-mentor-login',
  templateUrl: './mentor-login.component.html',
  styleUrls: ['./mentor-login.component.css']
})
export class MentorLoginComponent implements OnInit {

  mentor : Mentor = new Mentor();

  constructor(private mentorService:MentorService, private router: Router) { }

  ngOnInit() {
  }
  checkMentor() {
    this.mentorService.loginMentor(this.mentor.emailId, this.mentor.password)
      .subscribe((data: Mentor) => {
        console.log(data)
        if (data != null) {
          this.router.navigate(["/mentorhome"])
        }
      }
        , error => console.log(error));
    this.mentor = new Mentor();

  }


  mentorLogin() {
    this.checkMentor();
  }
}
