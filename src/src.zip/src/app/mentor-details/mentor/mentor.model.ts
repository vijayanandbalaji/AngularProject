export class Mentor{
    id:number;
    userName:String;
    emailId:String;
    linkedinUrl:String;
    mentorRegCode:String;
    mentorRegDateTime:Date;
    experience:number;
    active:number;
    password:String;
}