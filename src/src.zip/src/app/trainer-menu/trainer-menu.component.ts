import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trainer-menu',
  templateUrl: './trainer-menu.component.html',
  styleUrls: ['./trainer-menu.component.css']
})
export class TrainerMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
