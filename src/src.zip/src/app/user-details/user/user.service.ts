import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { User } from './user.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private baseUrl = 'http://localhost:9531/user';

  constructor(private http: HttpClient) { }

  createUser(user: User): Observable<Object> {
    return this.http.post(`${this.baseUrl}/user/create`, user);
  }


  loginUser(emailId : String,password: String): Observable<Object> {
    return this.http.get(`${this.baseUrl}/user/login/${emailId}/${password}`);
  }
}
