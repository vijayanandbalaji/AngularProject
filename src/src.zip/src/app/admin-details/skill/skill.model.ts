export class Skill{
    skillName:String;
    duration:String;
    toc:String;
    prerequites:String;
}