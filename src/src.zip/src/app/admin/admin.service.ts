import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  private baseUrl = 'http://localhost:9531/admin';
  constructor(private http: HttpClient) { }

  loginAdmin(email : String,password: String): Observable<Object> {
    return this.http.get(`${this.baseUrl}/admin/login/${email}/${password}`);
  }
}