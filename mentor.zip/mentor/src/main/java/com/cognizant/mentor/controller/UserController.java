package com.cognizant.mentor.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.mentor.model.UserDetails;
import com.cognizant.mentor.service.UserRepository;




@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	UserRepository userRepository;
	
	@PostMapping(value = "/user/create")
	public UserDetails postUser(@RequestBody UserDetails userDetails) {
		UserDetails userDetails2 = userRepository.save(userDetails);
		return userDetails2;
	}
	
	@GetMapping("/user/login/{emailId}/{password}")
	public UserDetails checkUserLogin(@PathVariable("emailId") String emailId,@PathVariable("password") String password) {
		
		UserDetails userDetails=userRepository.checkEmailAndPassword(emailId, password);
		
		System.out.println(userDetails);
			
		return userDetails;
	}
	
}
