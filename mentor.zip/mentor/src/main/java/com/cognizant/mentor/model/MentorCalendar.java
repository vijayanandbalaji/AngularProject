
package com.cognizant.mentor.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity

@Table(name = "mentor_calendar")
public class MentorCalendar {

	@Id
	@Column(name = "calendar_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "m_id")
	private MentorDetails mentorDetails;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "s_id")
	private SkillDetails skillDetails;
	

	@Column(name = "timing")
	private String timing;

	@Column(name = "start_date")
	private Date startDate;

	@Column(name = "end_date")
	private Date endDate;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public MentorDetails getMentorDetails() {
		return mentorDetails;
	}

	public void setMentorDetails(MentorDetails mentorDetails) {
		this.mentorDetails = mentorDetails;
	}

	public SkillDetails getSkillDetails() {
		return skillDetails;
	}

	public void setSkillDetails(SkillDetails skillDetails) {
		this.skillDetails = skillDetails;
	}

	public String getTiming() {
		return timing;
	}

	public void setTiming(String timing) {
		this.timing = timing;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	@Override
	public String toString() {
		return "MentorCalendar [id=" + id + ", mentorDetails=" + mentorDetails + ", skillDetails=" + skillDetails
				+ ", timing=" + timing + ", startDate=" + startDate + ", endDate=" + endDate + "]";
	}

	public MentorCalendar(MentorDetails mentorDetails, SkillDetails skillDetails, String timing, Date startDate,
			Date endDate) {
		super();
		this.mentorDetails = mentorDetails;
		this.skillDetails = skillDetails;
		this.timing = timing;
		this.startDate = startDate;
		this.endDate = endDate;
	}

	public MentorCalendar() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	
}
