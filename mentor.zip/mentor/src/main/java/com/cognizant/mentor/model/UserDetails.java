package com.cognizant.mentor.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="user_table")
public class UserDetails {
	
	@Column(name = "user_id")
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	@Column(name="user_name")
	private String userName;
	
	@Column(name="email_id")
	private String emailId;
	
	@Column(name="password")
	private String password;
	

	@Column(name="u_reg_datetime")
	private Date userRegDateTime;
	
	@Column(name="u_reg_code")
	private String userRegCode;
	
	@Column(name="active")
	private int active;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getUserRegDateTime() {
		return userRegDateTime;
	}

	public void setUserRegDateTime(Date userRegDateTime) {
		this.userRegDateTime = userRegDateTime;
	}

	public String getUserRegCode() {
		return userRegCode;
	}

	public void setUserRegCode(String userRegCode) {
		this.userRegCode = userRegCode;
	}

	public int getActive() {
		return active;
	}

	public void setActive(int active) {
		this.active = active;
	}

	@Override
	public String toString() {
		return "UserDetails [id=" + id + ", userName=" + userName + ", emailId=" + emailId + ", password=" + password
				+ ", userRegDateTime=" + userRegDateTime + ", userRegCode=" + userRegCode + ", active=" + active + "]";
	}

	public UserDetails(String userName, String emailId, String password) {
		
		this.userName = userName;
		this.emailId = emailId;
		this.password = password;
		this.userRegDateTime = new Date();
		this.userRegCode = "A1";
		this.active = 1;
	}

	public UserDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	
}
