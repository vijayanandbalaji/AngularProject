package com.cognizant.mentor.service;


import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.cognizant.mentor.model.UserDetails;

public interface UserRepository extends CrudRepository<UserDetails, Long> {
	@Query("Select u From UserDetails u where u.emailId = :emailId and u.password = :password")
	UserDetails checkEmailAndPassword(@Param("emailId") String emailId, @Param("password") String password);
}
