package com.cognizant.mentor.service;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.cognizant.mentor.model.AdminDetails;


public interface AdminRepository extends CrudRepository<AdminDetails, Long> {
	@Query("Select a From AdminDetails a where a.email = :email and a.password = :password")
	AdminDetails checkEmailAndPassword(@Param("email") String email, @Param("password") String password);
}
