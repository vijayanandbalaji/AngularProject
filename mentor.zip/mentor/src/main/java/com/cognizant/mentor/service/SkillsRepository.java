package com.cognizant.mentor.service;

import org.springframework.data.jpa.repository.JpaRepository;


import com.cognizant.mentor.model.SkillDetails;

public interface SkillsRepository extends JpaRepository<SkillDetails, Long> {

}
