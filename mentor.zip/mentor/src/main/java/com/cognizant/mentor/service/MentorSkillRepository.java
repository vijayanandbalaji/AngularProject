package com.cognizant.mentor.service;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.mentor.model.MentorSkills;

public interface MentorSkillRepository extends JpaRepository<MentorSkills, Long>{

}
