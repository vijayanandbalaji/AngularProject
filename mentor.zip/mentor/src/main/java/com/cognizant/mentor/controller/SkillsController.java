package com.cognizant.mentor.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.mentor.model.SkillDetails;
import com.cognizant.mentor.service.SkillsRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/skills")
public class SkillsController {
	
	@Autowired
	SkillsRepository skillsRepository;
	
	
	@PostMapping(value = "/skills/add")
	public SkillDetails addSkills(@RequestBody SkillDetails skillDetails) {
		SkillDetails skillDetails2= skillsRepository.save(skillDetails);
		return skillDetails2;
	}
	
	@GetMapping("/display/skills")
	public List<SkillDetails> displayskills() {
			
		  List<SkillDetails> skillDetails=new ArrayList<SkillDetails>();
		  
		  skillDetails=skillsRepository.findAll();
		  System.out.println(skillDetails);
			
		return  skillDetails;
	}
	
	
}
