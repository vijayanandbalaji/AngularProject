package com.cognizant.mentor.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.mentor.model.MentorDetails;

import com.cognizant.mentor.service.MentorRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/mentor")
public class MentorController {
	
	@Autowired
	MentorRepository mentorRepository;
	
	@PostMapping(value = "/mentor/create")
	public MentorDetails postMentor(@RequestBody MentorDetails mentorDetails) {
		MentorDetails mentorDetails2 = mentorRepository.save(mentorDetails);
		return mentorDetails2;
	}
	
	@GetMapping("/mentor/login/{emailId}/{password}")
	public MentorDetails checkMentorLogin(@PathVariable("emailId") String emailId,@PathVariable("password") String password) {
		
		MentorDetails mentorDetails=mentorRepository.checkEmailAndPassword(emailId, password);
		
		System.out.println(mentorDetails);
			
		return mentorDetails;
	
		
	}
	
}
