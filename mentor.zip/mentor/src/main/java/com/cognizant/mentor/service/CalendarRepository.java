package com.cognizant.mentor.service;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.mentor.model.MentorCalendar;

public interface CalendarRepository extends JpaRepository<MentorCalendar, Long> {

}
