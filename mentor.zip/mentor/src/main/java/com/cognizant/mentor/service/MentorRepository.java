package com.cognizant.mentor.service;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cognizant.mentor.model.MentorDetails;


public interface MentorRepository extends JpaRepository<MentorDetails, Long> {
	@Query("Select m From MentorDetails m where m.emailId = :emailId and m.password = :password")
	MentorDetails checkEmailAndPassword(@Param("emailId") String emailId, @Param("password") String password);
}
