package com.cognizant.mentor.controller;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.cognizant.mentor.model.MentorSkills;
import com.cognizant.mentor.service.MentorSkillRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/mentorskill")
public class MentorSkillController {
	@Autowired
	MentorSkillRepository mentorSkillRepository;
	
	@PostMapping(value = "/mentorskill/add")
	public MentorSkills addmentorSkills(@RequestBody MentorSkills mentorSkills) {
		MentorSkills mentorSkills2= mentorSkillRepository.save(mentorSkills);
		return mentorSkills2;
	}
	
	@GetMapping("/display/mentors")
	public List<MentorSkills> displaymentor() {
			
		  List<MentorSkills> mentorSkills=new ArrayList<MentorSkills>();
		  
		  mentorSkillRepository.findAll().forEach(mentorSkills::add);
		  System.out.println(mentorSkills);
		  return  mentorSkills;
	}
}
