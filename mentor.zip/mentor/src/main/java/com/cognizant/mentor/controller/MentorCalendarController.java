package com.cognizant.mentor.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.mentor.model.MentorCalendar;
import com.cognizant.mentor.service.CalendarRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/calendar")
public class MentorCalendarController {
	
	@Autowired
	CalendarRepository calendarRepository;
	
	@PostMapping(value = "/calendar/add")
	public MentorCalendar postMentor(@RequestBody MentorCalendar mentorCalendar) {
		MentorCalendar mentorCalendar2 = calendarRepository.save(mentorCalendar);
		return mentorCalendar2;
	}
}
