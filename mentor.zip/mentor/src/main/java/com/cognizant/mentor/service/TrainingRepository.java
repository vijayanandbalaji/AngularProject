/*
 * package com.cognizant.mentor.service;
 * 
 * import java.util.List;
 * 
 * import org.springframework.data.jpa.repository.JpaRepository; import
 * org.springframework.data.jpa.repository.Query; import
 * org.springframework.data.repository.query.Param;
 * 
 * import com.cognizant.mentor.model.TrainingDetails;
 * 
 * 
 * 
 * public interface TrainingRepository extends JpaRepository<TrainingDetails,
 * Long> {
 * 
 * 
 * 
 * @Query("Select t From TrainingDetails t where t.status = :status and t.userDetails.id = :userid"
 * ) List<TrainingDetails> findByStatusAndUserId(@Param("status") String
 * status,@Param("userid") long id);
 * 
 * 
 * }
 */