
package com.cognizant.mentor.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity

@Table(name = "mentor_skill_table")
public class MentorSkills {

	@Column(name = "mentor_skill_id")
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "m_id")
	private MentorDetails mentorDetails;

	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "s_id")
	private SkillDetails skillDetails;

	
	
	@Column(name = "self_rating")
	private int selfRating;

	@Column(name = "years_of_exp")
	private int experience;

	@Column(name = "trainings_delivered")
	private int trainingsDelivered;

	@Column(name = "facilities_offered")
	private String facilitiesOffered;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public MentorDetails getMentorDetails() {
		return mentorDetails;
	}

	public void setMentorDetails(MentorDetails mentorDetails) {
		this.mentorDetails = mentorDetails;
	}

	public SkillDetails getSkillDetails() {
		return skillDetails;
	}

	public void setSkillDetails(SkillDetails skillDetails) {
		this.skillDetails = skillDetails;
	}

	public int getSelfRating() {
		return selfRating;
	}

	public void setSelfRating(int selfRating) {
		this.selfRating = selfRating;
	}

	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	public int getTrainingsDelivered() {
		return trainingsDelivered;
	}

	public void setTrainingsDelivered(int trainingsDelivered) {
		this.trainingsDelivered = trainingsDelivered;
	}

	public String getFacilitiesOffered() {
		return facilitiesOffered;
	}

	public void setFacilitiesOffered(String facilitiesOffered) {
		this.facilitiesOffered = facilitiesOffered;
	}

	@Override
	public String toString() {
		return "MentorSkills [id=" + id + ", mentorDetails=" + mentorDetails + ", skillDetails=" + skillDetails
				+ ", selfRating=" + selfRating + ", experience=" + experience + ", trainingsDelivered="
				+ trainingsDelivered + ", facilitiesOffered=" + facilitiesOffered + "]";
	}

	public MentorSkills(MentorDetails mentorDetails, SkillDetails skillDetails, int selfRating, int experience,
			int trainingsDelivered, String facilitiesOffered) {
		super();
		this.mentorDetails = mentorDetails;
		this.skillDetails = skillDetails;
		this.selfRating = selfRating;
		this.experience = experience;
		this.trainingsDelivered = trainingsDelivered;
		this.facilitiesOffered = facilitiesOffered;
	}

	public MentorSkills() {
		super();
		// TODO Auto-generated constructor stub
	}

	
  
  }
