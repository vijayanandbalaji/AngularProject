
package com.cognizant.mentor.model;



import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity

@Table(name = "mentor_table")
public class MentorDetails {

	@Id
	@Column(name = "mentor_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@Column(name = "user_name")
	private String userName;

	@Column(name="email_id")
	private String emailId;
	
	@Column(name = "linkedin_url")
	private String linkedinUrl;


	@Column(name = "m_reg_code")
	private String mentorRegCode;

	@Column(name = "m_reg_date_time")
	private Date mentorRegDateTime;
	
	@Column(name = "years_of_experience")
	private int experience;

	@Column(name = "active")
	private int active;

	@Column(name = "password")
	private String password;

	public Date getMentorRegDateTime() {
		return mentorRegDateTime;
	}

	public void setMentorRegDateTime(Date mentorRegDateTime) {
		this.mentorRegDateTime = mentorRegDateTime;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getLinkedinUrl() {
		return linkedinUrl;
	}

	public void setLinkedinUrl(String linkedinUrl) {
		this.linkedinUrl = linkedinUrl;
	}

	public String getMentorRegCode() {
		return mentorRegCode;
	}

	public void setMentorRegCode(String mentorRegCode) {
		this.mentorRegCode = mentorRegCode;
	}

	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	public int getActive() {
		return active;
	}

	public void setActive(int active) {
		this.active = active;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	

	@Override
	public String toString() {
		return "MentorDetails [id=" + id + ", userName=" + userName + ", emailId=" + emailId + ", linkedinUrl="
				+ linkedinUrl + ", mentorRegCode=" + mentorRegCode + ", mentorRegDateTime=" + mentorRegDateTime
				+ ", experience=" + experience + ", active=" + active + ", password=" + password + "]";
	}

	public MentorDetails(String userName, String emailId, String linkedinUrl, String mentorRegCode,
			String mentorRegDateTime, int experience, int active, String password) {
		
		this.userName = userName;
		this.emailId = emailId;
		this.linkedinUrl = linkedinUrl;
		this.mentorRegCode = mentorRegCode;
		this.mentorRegDateTime = new Date();
		this.experience = experience;
		this.active = active;
		this.password = password;
	}

	public MentorDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	


  }
