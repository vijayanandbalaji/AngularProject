/*
 * package com.cognizant.mentor.model;
 * 
 * import javax.persistence.Entity; import javax.persistence.Table;
 * 
 * @Entity
 * 
 * @Table public class CommissionDetails {
 * 
 * }
 */